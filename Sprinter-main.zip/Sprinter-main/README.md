# Sprinter

To use our App, someone will first have to open the app and make an account. After making an account, they will be able to log in. Once logged in, they will be able to see a counter with start and stop buttons. These buttons are used to start a run workout. Upon starting, the user will be able to see stop and reset buttons, as well as a distance and time counter. The list of runs will be stored to their profile in a separate tab, where they can view their previous times, distances, and locations, by clicking on a run. (nouns / verbs bolded)

Someone would want to use this app, so they can track all their runs over a period of time, set goals and achieve them. This app would also be much simpler and less complex, than other comparable options. This app makes achieving running goals much easier, because they can see data from previous workouts and continually push themself to improve in their next run.

### Preview
<img width="296" alt="Screen Shot 2023-02-21 at 10 36 05 AM" src="https://user-images.githubusercontent.com/63936863/220389928-65e866b1-066e-4082-9b5a-99247da1430a.png">
